import React from "react";
import Header from "../Header/Header";

function Blog() {
  return (
    <div className=" Blog">
      <Header />
    </div>
  );
}

export default Blog;
