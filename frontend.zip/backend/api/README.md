# Backend

Install Node
Install Mongo DB
